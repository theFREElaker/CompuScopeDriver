#include "SystemCaps.h"
#include "CsStruct.h"
#include "CsDefines.h"


typedef int32	(* LPCSDRVGETACQUISITIONSYSTEMCAPS) (CSHANDLE, uInt32, PCSSYSTEMCONFIG, void*, uInt32*);


CSystemCaps::CSystemCaps(void)
{

}

CSystemCaps::~CSystemCaps(void)
{

}
