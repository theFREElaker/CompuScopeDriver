#ifndef CSSAVEFILE_H
#define CSSAVEFILE_H

#include "GageSystem.h"
#include "CsDisp.h"
#include "cstestqt.h"


void csSaveFile(CGageSystem	*m_pGageSystem, CSHANDLE myHandle, QString& fileName, char **  pHeaderStart, char ** f, int32& i32totalSize, int32& length);



#endif 
