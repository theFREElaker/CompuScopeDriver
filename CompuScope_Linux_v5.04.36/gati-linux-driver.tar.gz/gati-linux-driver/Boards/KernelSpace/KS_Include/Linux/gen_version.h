#define GEN_BUILD_NAME   "Current"
#define GEN_MAJOR_NUMBER "0"
#define GEN_MINOR_NUMBER "0"
#define GEN_BUILD_NUMBER "0"
